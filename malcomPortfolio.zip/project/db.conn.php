<?php 

# server name
$sName = "localhost";
# user name
$uName = "root";
# password
$pass = "";

# correct database name (just the DB name, not .sql file)
$db_name = "malcolm_db";
# port number (only change this if your MySQL is actually running on 4306)
$port = 3306;

# creating database connection
try {
    // Include the port number in the DSN
    $conn = new PDO("mysql:host=$sName;port=$port;dbname=$db_name", $uName, $pass);

    // Set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "Connection successful!";

} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>
